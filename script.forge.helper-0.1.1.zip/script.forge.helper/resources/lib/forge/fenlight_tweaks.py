# -*- coding: utf-8 -*-
"""Small edits The Forge makes to Fen Light (sort orders and two fixes).

Each edit is stored in resources/tweaks/fenlight.json as an exact before/after block. An edit is applied only
when its "before" block is found exactly once, so a Fen Light update that changed that code is left alone
rather than broken. The untouched file is kept beside it as <name>.forge-backup. Safe to run repeatedly:
Fen Light updates wipe these edits, and running this again puts them back.
"""
import os
import shutil

import xbmcvfs

from . import common


def apply_all(report=False):
    data = common.read_json(os.path.join(common.ADDON_PATH, "resources", "tweaks", "fenlight.json"), {}) or {}
    root = xbmcvfs.translatePath("special://home/addons/%s/" % data.get("addon", "plugin.video.fenlight"))
    if not os.path.isdir(root):
        if report:
            common.ok("Fen Light is not installed.")
        return False
    lines, all_ok = [], True
    for tweak in data.get("tweaks", []):
        path = os.path.join(root, *tweak["file"].split("/"))
        applied = present = skipped = 0
        try:
            with open(path, "r", encoding="utf-8", newline="") as handle:
                original = handle.read()
            crlf = "\r\n" in original
            text = original.replace("\r\n", "\n")
            for hunk in tweak["hunks"]:
                if hunk["new"] in text:
                    present += 1
                elif text.count(hunk["old"]) == 1:
                    text = text.replace(hunk["old"], hunk["new"])
                    applied += 1
                else:
                    skipped += 1
            if applied and not skipped:  # all of a file's edits or none, so it is never left half changed
                compile(text, path, "exec")  # never write a file that does not parse
                if not os.path.exists(path + ".forge-backup"):
                    shutil.copyfile(path, path + ".forge-backup")
                with open(path, "w", encoding="utf-8", newline="") as handle:
                    handle.write(text.replace("\n", "\r\n") if crlf else text)
        except Exception as exc:
            common.log("fenlight tweak %s failed: %r" % (tweak["file"], exc))
            skipped = len(tweak["hunks"])
        if skipped:
            all_ok = False
            state = "not applied, Fen Light has changed in this file"
        else:
            state = "applied" if applied else "already in place"
        lines.append("%s: %s" % (tweak["label"], state))
        common.log("fenlight tweak: %s: %s" % (tweak["label"], state))
    if report:
        common.ok("[CR]".join(lines) or "Nothing to apply.")
    return all_ok


def check():
    """Read-only: (all edits in place, short note). Changes nothing."""
    data = common.read_json(os.path.join(common.ADDON_PATH, "resources", "tweaks", "fenlight.json"), {}) or {}
    root = xbmcvfs.translatePath("special://home/addons/%s/" % data.get("addon", "plugin.video.fenlight"))
    if not os.path.isdir(root):
        return False, "Fen Light is not installed"
    total = present = 0
    for tweak in data.get("tweaks", []):
        try:
            with open(os.path.join(root, *tweak["file"].split("/")), "r", encoding="utf-8", newline="") as handle:
                text = handle.read().replace("\r\n", "\n")
        except Exception:
            text = ""
        for hunk in tweak["hunks"]:
            total += 1
            present += 1 if hunk["new"] in text else 0
    if present == total:
        return True, "in place"
    return False, "%d of %d in place" % (present, total)
