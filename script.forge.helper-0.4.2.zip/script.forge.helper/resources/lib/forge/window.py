# -*- coding: utf-8 -*-
"""The helper's home screen: actions on the left, installed and published versions on the right.

Everything shown is plain window properties (see script-forge-helper.xml). No list items are created here on
purpose: a Python list item that outlives its window is a known way to crash Kodi.
"""
import threading
import time

import xbmcgui

from . import common, update

XML = "script-forge-helper.xml"
ACTIONS = {101: "accounts", 102: "volume", 103: "tweaks", 104: "wizard", 105: "checklist", 106: "update"}
FOCUS = {name: control for control, name in ACTIONS.items()}
BACK = (9, 10, 92, 110)  # parent dir, previous menu, back, backspace

ORANGE, GREEN, GREY = "FFFF8A1F", "FF7BD88F", "FFA89F97"
_cache = {"at": 0.0, "published": None}


def _color(text, color):
    return "[COLOR %s]%s[/COLOR]" % (color, text)


def _published(fresh=False):
    """The repository listing, kept for a minute so reopening the screen is instant."""
    if fresh or _cache["published"] is None or time.time() - _cache["at"] > 60:
        from . import setup

        _cache["published"] = setup._repo_listing()
        _cache["at"] = time.time()
    return _cache["published"]


def forget():
    _cache["published"] = None


class HelperWindow(xbmcgui.WindowXMLDialog):
    def __new__(cls, *args, **kwargs):
        return super(HelperWindow, cls).__new__(cls, *args)

    def __init__(self, *args, **kwargs):
        super(HelperWindow, self).__init__(*args)
        self.choice = None
        self.focus = kwargs.get("focus")
        self.open = False

    def onInit(self):
        self.open = True
        self._show(None)
        if self.focus in FOCUS:
            try:
                self.setFocusId(FOCUS[self.focus])
            except RuntimeError:
                pass
        worker = threading.Thread(target=self._check)
        worker.daemon = True
        worker.start()

    def _check(self):
        try:
            published = _published()
        except Exception as exc:
            common.log("helper window: listing failed: %r" % exc)
            published = {}
        if self.open:
            try:
                self._show(published)
            except RuntimeError:
                pass

    def _show(self, published):
        """published: None while checking, {} when the repository could not be read."""
        behind = []
        for index, (addon_id, label) in enumerate(sorted(update.PARTS, key=lambda part: part[1].lower()), 1):
            have = update.installed_version(addon_id)
            latest = (published or {}).get(addon_id, "")
            if published is None:
                available, status = _color("...", GREY), _color("Checking", GREY)
            elif not latest:
                available, status = _color("?", GREY), _color("Could not check", GREY)
            elif not have:
                available, status = latest, _color("Not installed", GREY)
            elif update.is_newer(latest, have):
                behind.append(label)
                available, status = _color(latest, ORANGE), _color("Update available", ORANGE)
            else:
                available, status = latest, _color("Up to date", GREEN)
            key = "v%d." % index
            self.setProperty(key + "name", label)
            self.setProperty(key + "installed", have or "none")
            self.setProperty(key + "available", available)
            self.setProperty(key + "status", status)
        if published is None:
            summary, checked = "Checking for updates", ""
            advice = "Looking up the latest versions in the Forge repository."
            desc = "Check versions and install updates"
        elif not published:
            summary, checked = _color("Could not check for updates", ORANGE), "The Forge repository did not answer"
            advice = "The installed versions are shown. Check the network connection, then open this screen again."
            desc = "Check versions and install updates"
        elif behind:
            count = "1 update" if len(behind) == 1 else "%d updates" % len(behind)
            summary, checked = _color("%s available" % count, ORANGE), "Checked against the Forge repository just now"
            advice = "Behind: %s.[CR]Choose Update The Forge to install %s and restart Kodi." % (
                ", ".join(behind), "it" if len(behind) == 1 else "them")
            desc = "%s ready to install" % count
        else:
            summary, checked = _color("Everything is up to date", GREEN), "Checked against the Forge repository just now"
            advice = "Every part of The Forge on this device matches the latest published version."
            desc = "Nothing to install. Select to check again."
        self.setProperty("summary", summary)
        self.setProperty("checked", checked)
        self.setProperty("advice", advice)
        self.setProperty("update.desc", desc)

    def onClick(self, control_id):
        if control_id in ACTIONS:
            self.choice = ACTIONS[control_id]
            self.open = False
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.open = False
            self.close()


def choose(focus=None):
    """Show the screen and return the chosen action name, or None when it was closed."""
    common.not_busy()
    window = HelperWindow(XML, common.ADDON_PATH, "Default", "1080i", focus=focus)
    try:
        window.doModal()
        return window.choice
    finally:
        del window
