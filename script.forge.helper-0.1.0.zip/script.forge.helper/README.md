# Forge Helper 0.1.0

Companion add-on for The Forge skin. Forked from Chameleon Helper 0.2.18.

- **Setup wizard and checklist**: installs repositories and add-ons (Fen Light, TMDb Helper, YouTube and the
  skin's script add-ons), applies Fen Light starting values, and switches to the skin.
- **Accounts**: sign in once to Trakt and Real-Debrid, enter Premiumize, YouTube and metadata API keys once, and push
  them to installed add-ons. A background pass keeps Trakt tokens aligned (newest token wins, then it is re-pushed).
- **What to Watch**: pick type, genres, years, actor and a minimum star rating; get a shuffled list from TMDb
  (through TMDb Helper) and/or your Kodi library. Also served as a widget at
  `plugin://script.forge.helper/?mode=picks`.
- **Default volume amplification** and **speed settings sized to the device**.

## Removed from Chameleon Helper
Look presets and custom colour themes (presets.py, colors.py and their menu entries, router modes,
checklist row and wizard step). The Forge has one look.

## Before the setup wizard can install anything
setup.py points at a GitHub repository named `forge` under TLH88 and a repository add-on named
`repository.forge`. Publish those, or change GITHUB_REPO and REPO_ADDON at the top of setup.py.

## Connectors
One JSON file per add-on in resources/connectors. To support another add-on, drop a file with the same shape into
`addon_data/script.forge.helper/connectors/`. `"store": {"type": "settings"}` covers any add-on that keeps
credentials in normal Kodi settings; the Fen Light file shows the sqlite form.

## Where credentials live
`addon_data/script.forge.helper/accounts.json`, plain text, the same as every Kodi add-on stores them.
Anyone with access to the Kodi profile folder can read it.
