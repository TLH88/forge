# -*- coding: utf-8 -*-
"""Setup checklist: every step of the setup wizard on one page, with its live state.

Each row is read fresh from Kodi, Fen Light and the other add-ons every time the page is drawn, so it shows
what is true now, not what the wizard recorded when it ran. Choosing a row opens that step so it can be
changed or redone here, without going into Kodi's or Fen Light's own settings.
"""
import os

import xbmc
import xbmcgui
import xbmcvfs

from . import accounts, common, connectors, setup

GOOD = "[COLOR FF4CAF50]Done[/COLOR]"
TODO = "[COLOR FFFFB300]Not done[/COLOR]"
TMDBH = "plugin.video.themoviedb.helper"
YOUTUBE = "plugin.video.youtube"
SCRAPER_KEYS = ("provider.external", "external_scraper.name", "external_scraper.module")


# -- reading the current state ---------------------------------------------
def _fenlight():
    for connector in connectors.installed():
        if connector.addon_id == setup.FENLIGHT:
            return connector
    return None


def _targets():
    targets = [addon_id for addon_id, _ in setup.KODI_REPO_ADDONS] + [setup.FENLIGHT]
    try:
        targets += [a for a in setup.skin_dependencies() if a not in targets]
    except Exception:
        pass
    return targets + [setup.SKIN]


def addons_state():
    missing = [a for a in _targets() if not setup._ready(a)]
    if not missing:
        return True, "all installed"
    names = [setup.LABELS.get(a, a).split(" (")[0] for a in missing]
    return False, "missing: " + ", ".join(sorted(names, key=str.lower))


def account_state(service):
    return bool(accounts.is_signed_in(service)), accounts.status(service)


def tmdb_state():
    key = accounts.get("keys").get("tmdb")
    if not key:
        return False, "no key, home rows will be empty"
    fen = _fenlight()
    if fen:
        try:
            if fen._read("tmdb_api") != key:
                return False, "saved, but Fen Light has a different key"
        except Exception:
            pass
    return True, common.mask(key)


def tweaks_state():
    from . import fenlight_tweaks

    return fenlight_tweaks.check()


def scraper_state():
    fen = _fenlight()
    if not fen:
        return False, "Fen Light is not installed"
    try:
        on = fen._read("provider.external") == "true"
        name = fen._read("external_scraper.name")
    except Exception as exc:
        return False, str(exc)
    if on and name and name != "empty_setting":
        return True, name
    return False, "none set, nothing will be found to play"


def defaults_state():
    matched, total = setup.fenlight_defaults_state()
    if matched == total:
        return True, "all %d in place" % total
    return False, "%d of %d match The Forge's values" % (matched, total)


def do_defaults():
    data = setup._fenlight_defaults()
    fen = _fenlight()
    lines = []
    for item in data.get("settings", []):
        shown = item.get("name") or {"true": "On", "false": "Off"}.get(item["value"], item["value"])
        same = bool(fen) and fen._read(item["id"]) == item["value"]
        lines.append("%s   %s: %s" % (GOOD if same else TODO, item["label"], shown))
    lines.append("CocoScrapers sources switched on: " + ", ".join(data.get("scraper_sources_on", [])))
    lines.append("[B]Set all of these now[/B]")
    choice = common.select("The Forge's values for Fen Light", lines)
    if choice == len(lines) - 1:
        if setup.apply_fenlight_defaults():
            common.notify("Fen Light settings applied")
        else:
            common.ok("Some values could not be set. Check that Fen Light and CocoScrapers are installed.")


def player_state():
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/players/" % TMDBH)
    if not os.path.isfile(os.path.join(folder, "fenlight.json")):
        return False, "Fen Light player not added"
    try:
        import xbmcaddon

        default = xbmcaddon.Addon(TMDBH).getSetting("default_player_movies")
    except Exception:
        return False, "TMDb Helper is not installed"
    if default.startswith("fenlight.json"):
        return True, "Fen Light plays straight away"
    return False, "added, but not the default"


def mouse_state():
    result = common.jsonrpc("Settings.GetSettingValue", {"setting": "input.enablemouse"}) or {}
    on = bool(result.get("value"))
    return (not on), ("mouse on" if on else "mouse off")


def youtube_state():
    if not setup._ready(YOUTUBE):
        return True, "YouTube is not installed"
    try:
        import xbmcaddon

        port = int(xbmcaddon.Addon(YOUTUBE).getSetting("kodion.http.port") or 50152)
    except Exception:
        return False, "could not read the port"
    state = setup._port_state(port)
    if state == "blocked":
        return False, "port %d is refused by this system" % port
    return True, "port %d" % port


def volume_state():
    from . import volume

    return True, volume.label()


def do_volume():
    from . import volume

    volume.menu()


def splash_state():
    ok = setup.splash_installed()
    return ok, "Forge image" if ok else "Kodi's own image"


def do_splash():
    choice = common.select("Start-up image", ["Use the Forge image", "Go back to Kodi's own image"])
    if choice == 0:
        setup.configure_splash()
    elif choice == 1:
        setup.remove_splash()
    if choice >= 0:
        common.notify("Shown the next time Kodi starts")


def boot_state():
    if not setup.is_libreelec():
        return True, "only on LibreELEC boxes"
    ok = setup.boot_splash_installed()
    return ok, "Forge image" if ok else "LibreELEC logo"


def do_boot():
    if not setup.is_libreelec():
        common.ok("This changes the logo LibreELEC shows at power-on, so it only applies on a LibreELEC box.")
        return
    choice = common.select("LibreELEC boot image", ["Use the Forge image", "Go back to the LibreELEC logo"])
    if choice < 0:
        return
    ok = setup.install_boot_splash() if choice == 0 else setup.remove_boot_splash()
    if ok:
        common.notify("Shown the next time the box starts")
    else:
        common.ok("Could not write to the boot partition, so nothing was changed.")


def performance_state():
    from . import performance

    return performance.state()


def do_performance():
    from . import performance

    wanted = performance.plan()
    lines = ["Streaming buffer: %d MB, read-ahead adaptive" % wanted["buffer"]]
    if wanted["limit_gui"]:
        lines.append("Menus drawn at 1080p (video still plays at full resolution)")
    lines.append("Artwork cached smaller" if wanted["artwork"] else "Artwork at Kodi's normal size")
    memory = "%.1f GB of memory" % (wanted["memory"] / 1024.0) if wanted["memory"] else "an unknown amount of memory"
    if not common.confirm("For a box with %s:[CR]%s[CR]Apply these now?" % (memory, "[CR]".join(lines)), "Speed settings"):
        return
    ok, restart = performance.apply()
    if not ok:
        common.ok("Some speed settings could not be set on this system.")
    elif restart:
        common.ok("Done. Restart Kodi for the menu size and artwork changes to take effect.")
    else:
        common.notify("Speed settings applied")


def skin_state():
    active = xbmc.getSkinDir() == setup.SKIN
    return active, "active" if active else "another skin is active"


# -- changing a step ---------------------------------------------------------
def do_addons():
    ok, note = addons_state()
    question = "Everything is installed. Check and reinstall anyway?" if ok else "Install what is missing now?[CR]%s" % note
    if common.confirm(question, "Add-ons and repositories"):
        setup._install_step([])


def do_account(service):
    from . import menus

    menus._service_menu(service)
    accounts.push_service(service)


def do_tmdb():
    from . import menus

    menus._keys_menu()
    accounts.push_service("keys")


def do_tweaks():
    from . import fenlight_tweaks

    fenlight_tweaks.apply_all(report=True)


def do_scraper():
    fen = _fenlight()
    if not fen:
        common.ok("Fen Light is not installed. Use \"Add-ons and repositories\" first.")
        return
    have_coco = setup._ready("script.module.cocoscrapers")
    rows = ["Use CocoScrapers" + ("" if have_coco else " (installs it first)"), "Turn source finding off"]
    choice = common.select("Fen Light source finder", rows)
    if choice == 0:
        if not have_coco:
            setup.install_extra_repo(*[(r, u) for r, _, u in setup.EXTRA_REPOS if "coco" in r][0])
            setup.install_from_kodi("script.module.cocoscrapers")
        if not setup.configure_scrapers():
            common.ok("CocoScrapers could not be set. Check that it is installed, then try again.")
    elif choice == 1:
        fen.set_fixed({"provider.external": "false"})


def do_player():
    if setup.configure_players():
        common.notify("Fen Light is the default player")
    else:
        common.ok("Could not set the player. Check that TMDb Helper is installed.")


def do_mouse():
    _, note = mouse_state()
    turn_on = note == "mouse off"
    common.jsonrpc("Settings.SetSettingValue", {"setting": "input.enablemouse", "value": turn_on})


def do_youtube():
    if not setup._ready(YOUTUBE):
        common.ok("YouTube is not installed. Use \"Add-ons and repositories\" first.")
        return
    import xbmcaddon

    choice = common.select("YouTube local server port", ["Check it and fix it if needed", "Enter a port number"])
    if choice == 0:
        ok = setup.configure_youtube_port()
        common.notify("YouTube port is fine" if ok else "No working port found")
    elif choice == 1:
        value = xbmcgui.Dialog().numeric(0, "Port (1024 to 65535)")
        if value and 1024 <= int(value) <= 65535:
            xbmcaddon.Addon(YOUTUBE).setSetting("kodion.http.port", str(int(value)))
        elif value:
            common.ok("That is not a usable port number.")


def do_skin():
    if xbmc.getSkinDir() == setup.SKIN:
        common.notify("The Forge is already the active skin")
        return False
    if setup.switch_skin():
        _wait_build()
        return True
    common.ok("Could not switch to the Forge skin.")
    return False


def _wait_build():
    progress = setup.Progress("The Forge: finishing")
    try:
        setup.wait_for_menu_build(progress)
    finally:
        progress.close()


# rows in the order the wizard runs them
STEPS = (
    ("Add-ons and repositories", addons_state, do_addons),
    ("Trakt", lambda: account_state("trakt"), lambda: do_account("trakt")),
    ("Premiumize", lambda: account_state("pm"), lambda: do_account("pm")),
    ("TMDb and metadata keys", tmdb_state, do_tmdb),
    ("Fen Light tweaks", tweaks_state, do_tweaks),
    ("Fen Light source finder", scraper_state, do_scraper),
    ("Fen Light playback and results settings", defaults_state, do_defaults),
    ("Default player", player_state, do_player),
    ("Mouse pointer off", mouse_state, do_mouse),
    ("YouTube local server port", youtube_state, do_youtube),
    ("Default volume amplification", volume_state, do_volume),
    ("Start-up image", splash_state, do_splash),
    ("LibreELEC boot image", boot_state, do_boot),
    ("Speed settings for this box", performance_state, do_performance),
    ("Forge skin", skin_state, do_skin),
)


def menu():
    position = 0
    while True:
        rows, todo = [], 0
        for label, state, _ in STEPS:
            try:
                ok, note = state()
            except Exception as exc:
                ok, note = False, "could not check"
                common.log("checklist: %s: %r" % (label, exc))
            todo += 0 if ok else 1
            rows.append("%s   %s%s" % (GOOD if ok else TODO, label, ": %s" % note if note else ""))
        rows.append("[B]Run the whole setup again[/B]")
        rows.append("[B]Close[/B]")
        heading = "Setup checklist: all done" if not todo else "Setup checklist: %d to look at" % todo
        choice = common.select(heading, rows, preselect=position)
        if choice < 0 or choice == len(rows) - 1:
            return
        position = choice
        if choice == len(STEPS):
            setup.run()
            return
        try:
            STEPS[choice][2]()
        except Exception as exc:
            common.log("checklist: %s failed: %r" % (STEPS[choice][0], exc))
            common.ok("That step did not finish: %s" % exc)
