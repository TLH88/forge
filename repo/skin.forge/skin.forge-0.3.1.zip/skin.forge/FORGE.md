# The Forge 0.1.0 (base)

A custom Kodi skin by Merlin88 (Foundry 88 Labs).

The Forge is built on Chameleon, a personal fork of Arctic Horizon 2.1 by DeFiNiek, which continues
Arctic Horizon 2 by jurialmunkey. All credit for the underlying skin goes to them. Licensed CC BY-NC-SA 4.0
like the original: share alike, with attribution, non-commercial only.

## What this base is
The working starting point for the Forge rebuild: Chameleon's plumbing with a new identity and one look.
The screens still use the Arctic Horizon layouts. They are replaced one at a time from the Forge design.

## Changed from Chameleon 0.1.1
- New id and name: skin.forge, "The Forge". Installs beside Chameleon with its own settings.
- Requires script.forge.helper (fork of Chameleon Helper) and plugin.video.youtube (trailers).
- Presets and colour theming removed: the preset picker, save-preset, the colour pickers, the colour
  selector window (1111), the generated theme file and the five alternative colour themes.
- One colour theme (colors/defaults.xml) with the Forge palette. Highlight ffff7a1a, gradient ffffae45,
  progress ffff8a2a are the built-in fallbacks in Includes_Colors.xml.
- One font set (Default). Merlin88 Inferno Vector added as font_forge_title / font_forge_head / font_forge_small
  for select headers.
- English (en_gb) only.
- Skin strings and window properties renamed Chameleon.* to Forge.*.
- Tinted textures are built into addon_data/script.texturemaker/Forge, so Chameleon's are left alone.
- First start sets the Forge defaults once (text menu, glass menu bar, 105% focus zoom).

## Not changed yet
- Home, hubs, widgets, views, backgrounds, animations: still Arctic Horizon layouts.
- Live TV, games, weather and music windows are still present.
- media/ and extras/ are copied from Chameleon as they are (minus extras/presets and extras/previews/presets).
