# -*- coding: utf-8 -*-
"""Plugin entry point: serves the What to Watch picks as a browsable list or home widget."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

from forge import picker  # noqa: E402

if __name__ == "__main__":
    picker.serve(int(sys.argv[1]), sys.argv[2])
