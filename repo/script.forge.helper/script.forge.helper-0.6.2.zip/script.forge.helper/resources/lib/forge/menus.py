# -*- coding: utf-8 -*-
"""Dialog-based menus for the helper."""
from . import accounts, common, connectors


def _run(action):
    """Carry out one action from the home screen. Returns False when the helper should close afterwards."""
    if action == "accounts":
        accounts_menu()
    elif action == "volume":
        from . import volume
        volume.menu()
    elif action == "tweaks":
        from . import fenlight_tweaks
        fenlight_tweaks.apply_all(report=True)
    elif action == "wizard":
        from . import setup
        setup.run()
        return False
    elif action == "checklist":
        from . import checklist
        checklist.menu()
    elif action == "rollback":
        from . import update
        if update.rollback() == "restarting":
            return False
    elif action == "update":
        from . import update, window
        window.forget()  # look at the repository again, not at the copy the screen already has
        if update.run() == "restarting":
            return False
    return True


def main():
    try:
        from . import window
        focus = None
        while True:
            action = window.choose(focus)
            if not action or not _run(action):
                return
            focus = action
    except Exception as exc:  # the plain menu still works if the screen cannot be drawn
        common.log("helper window failed, using the plain menu: %r" % exc)
        _plain_menu()


def _plain_menu():
    from . import update

    order = ["accounts", "volume", "tweaks", "rollback", "wizard", "checklist", "update"]
    while True:
        choice = common.select("The Forge  (%s)" % update.summary(), [
            "Accounts (sign in once)",
            "Default volume amplification",
            "Reapply Fen Light tweaks",
            "Roll back a version (previous release of the skin or helper)",
            "Run setup wizard (all steps)",
            "Setup checklist (check or change each step)",
            "Update The Forge (check versions and install updates)",
        ])
        if choice < 0 or not _run(order[choice]):
            return


def accounts_menu():
    while True:
        rows = [
            ("keys", "Metadata API keys: %s" % accounts.status("keys")),
            ("pm", "Premiumize: %s" % accounts.status("pm")),
            ("rd", "Real-Debrid: %s" % accounts.status("rd")),
            ("trakt", "Trakt: %s" % accounts.status("trakt")),
            ("youtube", "YouTube API (trailers): %s" % accounts.status("youtube")),
            ("push", "Push everything to add-ons now"),
            ("addons", "Show connected add-ons"),
        ]
        choice = common.select("Accounts", [label for _, label in rows])
        if choice < 0:
            # refresh once on the way out, so the menu is not torn down mid-use
            if accounts.refresh_skin():
                common.notify("Accounts updated, skin refreshed")
            return
        key = rows[choice][0]
        if key == "push":
            accounts.push_all(report=True)
        elif key == "addons":
            _show_addons()
        elif key == "keys":
            _keys_menu()
        else:
            _service_menu(key)


def _service_menu(service):
    label = accounts.LABELS[service]
    while True:
        rows = []
        if service == "trakt":
            rows += [("signin", "Sign in with a code"), ("appkeys", "Set Trakt API app keys")]
        elif service == "rd":
            rows += [("signin", "Sign in with a code")]
        elif service == "pm":
            delegate = accounts.delegate_connector("pm")
            if delegate:
                rows += [("delegate", "Sign in with a code (through %s)" % delegate.name)]
            rows += [("signin", "Enter API key instead")]
        elif service == "youtube":
            rows += [("signin", "Enter API key, client ID and secret")]
        rows += [("import", "Import from an add-on that is already signed in"), ("push", "Push to add-ons now")]
        if accounts.is_signed_in(service):
            rows.append(("signout", "Remove from The Forge"))
        choice = common.select("%s: %s" % (label, accounts.status(service)), [text for _, text in rows])
        if choice < 0:
            return
        action = rows[choice][0]
        if action == "signin":
            {"trakt": accounts.trakt_sign_in, "rd": accounts.rd_sign_in, "pm": accounts.pm_set_key, "youtube": accounts.youtube_set_keys}[service]()
        elif action == "delegate":
            accounts.delegated_sign_in(service)
        elif action == "appkeys":
            accounts.trakt_set_app_keys()
        elif action == "import":
            accounts.import_from_addon(service)
        elif action == "push":
            accounts.push_service(service, quiet=False)
        elif action == "signout":
            accounts.sign_out(service)


def _keys_menu():
    while True:
        saved = accounts.get("keys")
        rows = ["%s: %s" % (heading, common.mask(saved.get(field)) or "not set") for field, heading in accounts.KEY_FIELDS]
        rows.append("Import from an add-on")
        choice = common.select("Metadata API keys", rows)
        if choice < 0:
            return
        if choice == len(accounts.KEY_FIELDS):
            accounts.import_from_addon("keys")
        else:
            accounts.keys_set(accounts.KEY_FIELDS[choice][0])


def _show_addons():
    lines = []
    for connector in sorted(connectors.load_all(), key=lambda c: c.name.lower()):
        services = ", ".join(accounts.LABELS[s] for s in accounts.SERVICES if connector.supports(s))
        state = "installed" if connector.installed else "not installed"
        lines.append("[B]%s[/B] (%s): %s" % (connector.name, state, services))
        if connector.own_trakt_auth and connector.installed:
            lines.append("    Trakt for this add-on uses its own sign-in.")
    common.ok("[CR]".join(lines), "Connected add-ons")
