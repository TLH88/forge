# -*- coding: utf-8 -*-
"""Default volume amplification for every video.

Kodi keeps volume amplification per item and has no settings page for a global value, and it gives add-ons no
call to set it. What it does have is the "volume amplification up/down" remote actions, which move the value
1 dB at a time between 0 and 30. So when a video starts, the helper steps the value down to 0 and then up to
the chosen level. The skin hides Kodi's slider pop-up while that happens (property The Forge.VolAmpBusy).
"""
import xbmc
import xbmcgui

from . import common

MAXIMUM = 30
BUSY = "Forge.VolAmpBusy"


def get():
    options = common.read_json(common.data_file("options.json"), {}) or {}
    try:
        return max(0, min(MAXIMUM, int(options.get("volume_amp_db", 0))))
    except (TypeError, ValueError):
        return 0


def label(value=None):
    value = get() if value is None else value
    return "%d dB" % value if value else "Off"


def save(value):
    options = common.read_json(common.data_file("options.json"), {}) or {}
    options["volume_amp_db"] = int(value)
    common.write_json(common.data_file("options.json"), options)
    xbmc.executebuiltin("Skin.SetString(Forge.VolAmp,%s)" % label(int(value)))


def sync_label():
    xbmc.executebuiltin("Skin.SetString(Forge.VolAmp,%s)" % label())


def menu():
    current = get()
    values = list(range(0, MAXIMUM + 1, 2))
    rows = ["Off (leave each video as Kodi has it)"] + ["%d dB" % v for v in values[1:]]
    preselect = values.index(current) if current in values else 0
    choice = common.select("Default volume amplification", rows, preselect=preselect)
    if choice < 0:
        return False
    save(values[choice])
    if xbmc.getCondVisibility("Player.HasVideo"):
        apply(force=True)
    else:
        common.notify("Volume amplification: %s. Used from the next video." % label())
    return True


def _step(action, count, monitor):
    for _ in range(count):
        common.jsonrpc("Input.ExecuteAction", {"action": action})
        if monitor.waitForAbort(0.02):
            return False
    return True


def apply(force=False):
    """Bring the playing video to the saved level. With the setting off, nothing is touched."""
    target = get()
    if not target and not force:
        return False
    if not xbmc.getCondVisibility("Player.HasVideo"):
        return False
    if xbmc.getCondVisibility("Player.Passthrough"):
        common.log("volume amplification skipped: passthrough audio cannot be amplified")
        return False
    monitor = xbmc.Monitor()
    window = xbmcgui.Window(10000)
    window.setProperty(BUSY, "true")
    try:
        if _step("volampdown", MAXIMUM, monitor):  # down to the floor, whatever this item was saved with
            _step("volampup", target, monitor)
        monitor.waitForAbort(1.5)  # the slider pop-up closes itself a second after the last step; stay hidden until then
    finally:
        window.clearProperty(BUSY)
    common.log("volume amplification set to %d dB" % target)
    return True
