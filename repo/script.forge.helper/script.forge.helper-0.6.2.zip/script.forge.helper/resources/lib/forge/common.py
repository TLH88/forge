# -*- coding: utf-8 -*-
"""Small shared helpers: paths, logging, JSON files, dialogs."""
import json
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "script.forge.helper"
ADDON = xbmcaddon.Addon(ADDON_ID)
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
DATA_PATH = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
TITLE = "The Forge"


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, message), level)


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
    return path


def data_file(*parts):
    ensure_dir(DATA_PATH)
    return os.path.join(DATA_PATH, *parts)


def read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {} if default is None else default


def write_json(path, data):
    ensure_dir(os.path.dirname(path))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
    os.replace(tmp, path)


def has_addon(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def not_busy():
    """Drop the start-up spinner before showing a dialog (a spinner on top would block it)."""
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")


def notify(message, time_ms=4000):
    xbmcgui.Dialog().notification(TITLE, message, xbmcgui.NOTIFICATION_INFO, time_ms)


def ok(message, heading=TITLE):
    not_busy()
    xbmcgui.Dialog().ok(heading, message)


def confirm(message, heading=TITLE):
    not_busy()
    return xbmcgui.Dialog().yesno(heading, message)


def select(heading, labels, preselect=-1):
    not_busy()
    return xbmcgui.Dialog().select(heading, labels, preselect=preselect)


def text_input(heading, default="", hidden=False):
    not_busy()
    option = xbmcgui.ALPHANUM_HIDE_INPUT if hidden else 0
    return xbmcgui.Dialog().input(heading, defaultt=default, type=xbmcgui.INPUT_ALPHANUM, option=option)


def mask(value):
    value = value or ""
    if len(value) <= 8:
        return "*" * len(value)
    return "%s...%s" % (value[:4], value[-4:])


def jsonrpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result")
    except ValueError:
        return None
