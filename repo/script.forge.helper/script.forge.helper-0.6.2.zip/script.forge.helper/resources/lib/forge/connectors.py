# -*- coding: utf-8 -*-
"""Connector engine.

A connector is a JSON file describing where one add-on keeps its account
settings. Built-in connectors ship in resources/connectors; anything dropped in
addon_data/script.forge.helper/connectors/ is loaded too (and wins on a
name clash), so new add-ons can be supported without touching code.
"""
import os
import re
import sqlite3

import xbmcaddon
import xbmcgui
import xbmcvfs

from . import common

BUILTIN_DIR = os.path.join(common.ADDON_PATH, "resources", "connectors")
USER_DIR = os.path.join(common.DATA_PATH, "connectors")
FIELD = re.compile(r"^\{(\w+)\}$")


def load_all():
    found = {}
    for folder in (BUILTIN_DIR, USER_DIR):
        if not os.path.isdir(folder):
            continue
        for name in sorted(os.listdir(folder)):
            if name.endswith(".json"):
                data = common.read_json(os.path.join(folder, name))
                if data.get("addon") and data.get("services"):
                    found[data["addon"]] = Connector(data)
    return list(found.values())


def installed():
    return [c for c in load_all() if c.installed]


class Connector(object):
    def __init__(self, data):
        self.data = data
        self.addon_id = data["addon"]
        self.name = data.get("name", self.addon_id)
        self.store = data.get("store", {"type": "settings"})
        self.services = data["services"]
        self.empty_values = set(data.get("empty_values", [""]))
        self.own_trakt_auth = data.get("own_trakt_auth")
        self.sign_in = data.get("sign_in", {})
        self.after_push = data.get("after_push", {})

    @property
    def installed(self):
        return bool(common.has_addon(self.addon_id))

    def supports(self, service):
        return service in self.services

    # -- low level -----------------------------------------------------
    def _db_path(self):
        return xbmcvfs.translatePath(self.store["path"])

    def _read(self, key):
        if self.store["type"] == "sqlite":
            path = self._db_path()
            if not os.path.isfile(path):
                return ""
            con = sqlite3.connect(path, timeout=10)
            try:
                row = con.execute(self.store["select"], {"key": key}).fetchone()
            finally:
                con.close()
            return "" if row is None or row[0] is None else str(row[0])
        return xbmcaddon.Addon(self.addon_id).getSetting(key)

    def _write_many(self, pairs):
        if self.store["type"] == "sqlite":
            path = self._db_path()
            if not os.path.isfile(path):
                raise IOError("%s has not created its settings database yet. Open it once, then push again." % self.name)
            con = sqlite3.connect(path, timeout=10)
            try:
                for key, value in pairs:
                    cur = con.execute(self.store["update"], {"key": key, "value": value})
                    if cur.rowcount == 0:
                        con.execute(self.store["insert"], {"key": key, "value": value})
                con.commit()
            finally:
                con.close()
            pattern = self.store.get("window_property")
            if pattern:
                window = xbmcgui.Window(10000)
                for key, value in pairs:
                    window.setProperty(pattern.format(key=key), value)
            return
        addon = xbmcaddon.Addon(self.addon_id)
        for key, value in pairs:
            addon.setSetting(key, value)

    # -- public --------------------------------------------------------
    def push(self, service, account):
        """Write one service's credentials. Fields the hub has no value for are left alone."""
        pairs = []
        for key, template in self.services.get(service, {}).items():
            match = FIELD.match(template)
            if match:
                value = account.get(match.group(1))
                if value in (None, ""):
                    continue
                pairs.append((key, str(value)))
            else:
                pairs.append((key, template))
        if not [p for p in pairs if FIELD.match(self.services[service][p[0]])]:
            return False  # nothing real to push; do not flip "enabled" switches on their own
        self._write_many(pairs)
        return True

    def set_fixed(self, pairs):
        """Write plain settings (not account fields), for example which source finder an add-on uses."""
        self._write_many([(key, str(value)) for key, value in pairs.items()])
        return True

    def pull(self, service):
        """Read one service's credentials back out of the add-on."""
        account = {}
        for key, template in self.services.get(service, {}).items():
            match = FIELD.match(template)
            if not match:
                continue
            value = self._read(key)
            if value not in self.empty_values:
                account[match.group(1)] = value
        return account
