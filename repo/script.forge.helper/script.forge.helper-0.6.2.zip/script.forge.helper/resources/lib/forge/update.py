# -*- coding: utf-8 -*-
"""Version check and one-press update for everything The Forge publishes.

Kodi only looks at add-on repositories about once a day, so a new release can sit unnoticed for a while.
This reads the Forge repository listing directly, shows what is installed next to what is published, and
installs anything that is behind.
"""
import os
import re
import shutil
import zipfile

import xbmc
import xbmcgui

from . import common, setup, silent

# what the Forge repository publishes, in the order it is updated. The helper goes last: it is the code
# that is running.
PARTS = [
    ("skin.forge", "The Forge skin"),
    ("plugin.video.fenlight", "Fen Light"),
    ("repository.forge", "Forge repository"),
    ("script.forge.helper", "Forge Helper"),
]
WORK = os.path.join(setup.PACKAGES, "_forge_update")


_fresh = {"at": 0.0, "base": None}


def repo_base():
    """Where to read the repository from, pinned to the newest commit.

    GitHub serves files on the main branch from a cache that can be five minutes old, so a release published
    a moment ago would look like it is not there yet. Asking for the newest commit id first, and reading the
    files of that exact commit, always gives the latest release.
    """
    import time

    base = setup._base("repo_base", setup.REPO_BASE)
    if base != setup.REPO_BASE:
        return base  # a test folder, fork or mirror: use it as given
    if _fresh["base"] and time.time() - _fresh["at"] < 60:
        return _fresh["base"]
    try:
        import requests

        response = requests.get("https://api.github.com/repos/%s/%s/commits/main" % (setup.GITHUB_USER, setup.GITHUB_REPO),
                                headers={"Accept": "application/vnd.github.sha", "User-Agent": "Kodi Forge Helper"},
                                timeout=15)
        response.raise_for_status()
        commit = response.text.strip()
        if not re.match(r"^[0-9a-f]{40}$", commit):
            raise ValueError("unexpected answer")
        _fresh["base"] = base.replace("/main/", "/%s/" % commit)
        _fresh["at"] = time.time()
        return _fresh["base"]
    except Exception as exc:
        common.log("update: newest commit not available, reading the main branch: %r" % exc)
        return base


def listing():
    """addon id -> published version, read from the repository's addons.xml."""
    text = setup._read_text(setup._join(repo_base(), "addons.xml"))
    return dict(re.findall(r'<addon[^>]*?id="([^"]+)"[^>]*?version="([^"]+)"', text))


def installed_version(addon_id):
    """The version in the add-on's own addon.xml on disk, which is what is actually there to run."""
    path = os.path.join(setup.HOME_ADDONS, addon_id, "addon.xml")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            found = re.search(r'<addon[^>]*?\bversion="([^"]+)"', handle.read(), flags=re.S)
        return found.group(1) if found else ""
    except (OSError, UnicodeDecodeError):
        return ""


def summary():
    """Short text for menus: 'skin 0.2.2, helper 0.3.0'."""
    return "skin %s, helper %s" % (installed_version("skin.forge") or "not installed",
                                   installed_version(common.ADDON_ID) or "?")


def is_newer(latest, have):
    return silent._ver(latest) > silent._ver(have)


def status():
    """[(addon id, label, installed, published, behind)] for every part of The Forge."""
    published = listing()
    rows = []
    for addon_id, label in PARTS:
        have, latest = installed_version(addon_id), published.get(addon_id, "")
        # a part that is not installed at all is the setup wizard's job, not an update
        behind = bool(latest) and bool(have) and is_newer(latest, have)
        rows.append((addon_id, label, have, latest, behind))
    return rows


def _unpack(zip_path, addon_id):
    """Unpack into a work folder next to the add-ons, so a failed download or a bad zip never touches the
    copy that is installed."""
    shutil.rmtree(WORK, ignore_errors=True)
    os.makedirs(WORK)
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        if not names or not all(n.startswith(addon_id + "/") and ".." not in n.split("/") for n in names):
            raise ValueError("unexpected contents in %s" % os.path.basename(zip_path))
        if archive.testzip():
            raise ValueError("%s did not download cleanly" % os.path.basename(zip_path))
    silent.extract_zip(zip_path, WORK, addon_id)
    fresh = os.path.join(WORK, addon_id)
    if not os.path.isfile(os.path.join(fresh, "addon.xml")):
        raise ValueError("%s has no addon.xml" % os.path.basename(zip_path))
    return fresh


def _copy_over(source, target):
    """Write the new files over the old ones. Used when the folder itself cannot be swapped because
    something in it is open, which is normal on Windows for the skin in use."""
    for folder, _, files in os.walk(source):
        out = os.path.join(target, os.path.relpath(folder, source))
        os.makedirs(out, exist_ok=True)
        for name in files:
            shutil.copyfile(os.path.join(folder, name), os.path.join(out, name))


def _swap_in(fresh, addon_id):
    target = os.path.join(setup.HOME_ADDONS, addon_id)
    old = os.path.join(WORK, addon_id + ".old")
    if not os.path.isdir(target):
        shutil.move(fresh, target)
        return
    try:
        os.rename(target, old)
    except OSError:
        _copy_over(fresh, target)
        return
    try:
        os.rename(fresh, target)
    except OSError:
        os.rename(old, target)  # put the installed copy back exactly as it was
        raise


def install(addon_id, version):
    base = repo_base()
    name = "%s-%s.zip" % (addon_id, version)
    zip_path = setup._download(setup._join(base, addon_id, name), os.path.join(setup.PACKAGES, name))
    try:
        _swap_in(_unpack(zip_path, addon_id), addon_id)
    finally:
        try:
            os.remove(zip_path)
        except OSError:
            pass
        shutil.rmtree(WORK, ignore_errors=True)
    return installed_version(addon_id) == version


def _report(rows):
    lines = []
    for _, label, have, latest, behind in rows:
        if behind:
            lines.append("[COLOR FFFF8A1F]%s: %s installed, %s available[/COLOR]" % (label, have or "not", latest))
        else:
            lines.append("%s: %s (up to date)" % (label, have) if have else "%s: not installed" % label)
    return "[CR]".join(lines)


def run():
    try:
        rows = status()
    except Exception as exc:
        common.log("update: listing failed: %r" % exc)
        return common.ok("Installed: %s.[CR]The Forge repository could not be reached to check for updates. "
                         "Check the network connection and try again." % summary(), "The Forge versions")
    behind = [row for row in rows if row[4]]
    if not behind:
        return common.ok(_report(rows), "The Forge is up to date")
    if not common.confirm(_report(rows) + "[CR][CR]Update now?", "The Forge update"):
        return None
    common.not_busy()
    progress = xbmcgui.DialogProgress()
    progress.create("The Forge update", "Starting")
    done, failed = [], []
    try:
        for position, (addon_id, label, _, latest, _) in enumerate(behind):
            progress.update(int(100.0 * position / len(behind)), "Updating %s to %s" % (label, latest))
            try:
                (done if install(addon_id, latest) else failed).append(label)
            except Exception as exc:
                common.log("update: %s failed: %r" % (addon_id, exc))
                failed.append(label)
    finally:
        progress.close()
    xbmc.executebuiltin("UpdateLocalAddons", True)
    message = "Now installed: %s." % summary()
    if failed:
        message += "[CR]Could not update: %s. Nothing was changed for those; try again in a few minutes." % ", ".join(failed)
    if not done:
        return common.ok(message, "The Forge update")
    if common.confirm(message + "[CR][CR]Kodi needs a restart to load the new files. Restart now?", "The Forge update"):
        xbmc.executebuiltin("RestartApp")
        return "restarting"
    return None


def previous_versions():
    """addon id -> the release kept in the repository from before the current one (previous.json)."""
    import json

    text = setup._read_text(setup._join(repo_base(), "previous.json"))
    return {key: value for key, value in json.loads(text).items() if isinstance(value, str)}


def rollback():
    """Put one part of The Forge back to the release before the current one."""
    try:
        previous = previous_versions()
    except Exception as exc:
        common.log("rollback: listing failed: %r" % exc)
        return common.ok("The Forge repository could not be reached, so there is nothing to roll back to "
                         "right now. Check the network connection and try again.", "Roll back")
    choices = []
    for addon_id, label in sorted(PARTS, key=lambda part: part[1].lower()):
        have, older = installed_version(addon_id), previous.get(addon_id, "")
        if have and older and is_newer(have, older):
            choices.append((addon_id, label, have, older))
    if not choices:
        return common.ok("Installed: %s.[CR]Nothing here is newer than the saved previous release, so there "
                         "is nothing to roll back." % summary(), "Roll back")
    pick = common.select("Roll back which part?", ["%s:  %s  to  %s" % (label, have, older)
                                                   for _, label, have, older in choices])
    if pick < 0:
        return None
    addon_id, label, have, older = choices[pick]
    if not common.confirm("Put %s back from %s to %s?[CR][CR]Kodi installs the newest release again at its "
                          "next automatic update check, usually within a day, so this buys time for a fix "
                          "rather than staying put for good." % (label, have, older), "Roll back"):
        return None
    common.not_busy()
    progress = xbmcgui.DialogProgress()
    progress.create("Roll back", "Installing %s %s" % (label, older))
    try:
        worked = install(addon_id, older)
    except Exception as exc:
        common.log("rollback: %s failed: %r" % (addon_id, exc))
        worked = False
    finally:
        progress.close()
    if not worked:
        return common.ok("%s could not be rolled back. Nothing was changed." % label, "Roll back")
    xbmc.executebuiltin("UpdateLocalAddons", True)
    if common.confirm("%s is back on %s.[CR][CR]Kodi needs a restart to load it. Restart now?" % (label, older),
                      "Roll back"):
        xbmc.executebuiltin("RestartApp")
        return "restarting"
    return None
