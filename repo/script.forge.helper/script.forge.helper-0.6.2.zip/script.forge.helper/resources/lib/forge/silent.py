# -*- coding: utf-8 -*-
"""Quiet add-on installer for the setup wizard.

Kodi's own InstallAddon asks "Would you like to download this add-on?" for every add-on, and it will not
fetch a dependency from a different third-party repository. This module does the same job without the
questions: it reads the listings of every repository installed on the device, works out everything a set
of add-ons needs, downloads the zips, unpacks them and switches them on.

Add-ons with compiled parts (inputstream and friends) differ per device, so those are left to Kodi's
installer, which knows which build fits.
"""
import gzip
import io
import os
import re
import shutil
import zipfile
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

from . import common

HOME_ADDONS = xbmcvfs.translatePath("special://home/addons/")
SYSTEM_ADDONS = xbmcvfs.translatePath("special://xbmc/addons/")
PACKAGES = os.path.join(HOME_ADDONS, "packages")
OFFICIAL_BY_MAJOR = {19: "matrix", 20: "nexus", 21: "omega", 22: "piers"}
HEADERS = {"User-Agent": "Kodi Forge setup"}


def _ver(text):
    """Loose version key: '5.1.11~nexus' -> (5, 1, 11). Good enough to pick the newest and compare needs."""
    return tuple(int(n) for n in re.findall(r"\d+", (text or "0").split("~")[0].split("+")[0])[:4]) or (0,)


def kodi_version():
    return _ver(xbmc.getInfoLabel("System.BuildVersion").split(" ")[0])


def _has(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def _on(addon_id):
    """Installed AND switched on. System.HasAddon alone is also true for an add-on that is switched off."""
    return _has(addon_id) and xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % addon_id)


def _get(url):
    import requests

    response = requests.get(url, headers=HEADERS, timeout=60)
    response.raise_for_status()
    return response.content


def _rpc(method, params):
    import json

    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except Exception:
        return {}


def _known(addon_id):
    """True once Kodi has registered the add-on, switched on or not."""
    return "result" in _rpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]})


def enable_all(addon_ids, seconds=60):
    """Switch on add-ons that are present but off. Left off, Kodi nags about each one at every start."""
    import time

    monitor = xbmc.Monitor()
    deadline = time.time() + seconds
    while time.time() < deadline:
        pending = [a for a in addon_ids if not _on(a)]
        if not pending:
            return True
        for addon_id in pending:
            if _known(addon_id):
                _rpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
        if monitor.waitForAbort(1.5):
            break
    return not [a for a in addon_ids if not _on(a)]


def repository_dirs():
    """Every (info url, data dir) published by the repository add-ons on this device that fits this Kodi."""
    me = kodi_version()
    found, official = [], False
    for base in (SYSTEM_ADDONS, HOME_ADDONS):
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            path = os.path.join(base, name, "addon.xml")
            if not name.startswith("repository.") or not os.path.isfile(path):
                continue
            try:
                root = ET.parse(path).getroot()
            except ET.ParseError:
                continue
            for ext in root.findall("extension"):
                if ext.get("point") != "xbmc.addon.repository":
                    continue
                dirs = ext.findall("dir") or [ext]
                for entry in dirs:
                    low, high = entry.get("minversion"), entry.get("maxversion")
                    if (low and me < _ver(low)) or (high and me > _ver(high)):
                        continue
                    info, data = entry.findtext("info"), entry.findtext("datadir")
                    if info and data:
                        found.append((info.strip(), data.strip().rstrip("/"), name))
                        official = official or name == "repository.xbmc.org"
    if not official and me[0] in OFFICIAL_BY_MAJOR:  # some Kodi builds ship without the official repository add-on
        base = "https://mirrors.kodi.tv/addons/%s" % OFFICIAL_BY_MAJOR[me[0]]
        found.insert(0, (base + "/addons.xml.gz", base, "repository.xbmc.org"))
    return found


def load_index():
    """addon id -> newest entry across all repositories: version, needs, zip url, compiled or not."""
    index = {}
    for info, data, repo in repository_dirs():
        try:
            raw = _get(info)
            if info.split("?")[0].endswith(".gz") or raw[:2] == b"\x1f\x8b":
                raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
            root = ET.fromstring(raw)
        except Exception as exc:
            common.log("silent: could not read %s: %r" % (info, exc))
            continue
        for addon in root.iter("addon"):
            addon_id, version = addon.get("id"), addon.get("version")
            if not addon_id or not version:
                continue
            needs = [(i.get("addon"), i.get("optional") == "true") for i in addon.iter("import") if i.get("addon")]
            points = [e.get("point", "") for e in addon.findall("extension")]
            compiled = any(p.startswith("kodi.") for p in points) or any(
                e.get("library_linux") or e.get("library_windx") or e.get("library_android") for e in addon.findall("extension"))
            path = ""
            for ext in addon.findall("extension"):
                if ext.get("point") == "xbmc.addon.metadata" and ext.findtext("path"):
                    path = ext.findtext("path").strip()
            entry = {"id": addon_id, "version": version, "needs": needs, "compiled": compiled, "repo": repo,
                     "url": "%s/%s" % (data, path or "%s/%s-%s.zip" % (addon_id, addon_id, version))}
            if addon_id not in index or _ver(version) > _ver(index[addon_id]["version"]):
                index[addon_id] = entry
    return index


def plan(targets, index):
    """Everything to install for the targets, dependencies first. Returns (ordered entries, ids nobody lists)."""
    order, seen, missing, asleep = [], set(), [], []

    def visit(addon_id, optional=False):
        if addon_id in seen or addon_id.startswith(("xbmc.", "kodi.")):
            return
        seen.add(addon_id)
        if _has(addon_id):
            if not _on(addon_id):
                asleep.append(addon_id)  # present but switched off: just needs switching on
            return
        entry = index.get(addon_id)
        if not entry:
            if not optional:
                missing.append(addon_id)
            return
        for need, is_optional in entry["needs"]:
            visit(need, is_optional)
        order.append(entry)

    for target in targets:
        visit(target)
    return order, missing, asleep


def extract_zip(zip_path, destination, addon_id):
    """Unpack an add-on zip. Paths are written as UTF-8 bytes, so file names with accents work even on
    devices whose system locale is plain ASCII (common on appliance-style Kodi boxes)."""
    dest = os.fsencode(destination) if not isinstance(destination, bytes) else destination
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        if not names or not all(n.startswith(addon_id + "/") and ".." not in n.split("/") for n in names):
            raise ValueError("unexpected contents in %s" % os.path.basename(zip_path))
        target = os.path.join(dest, addon_id.encode("utf-8"))
        if os.path.isdir(target):
            shutil.rmtree(target, ignore_errors=True)
        for info in archive.infolist():
            out = os.path.join(dest, *[part.encode("utf-8") for part in info.filename.split("/") if part])
            if info.filename.endswith("/"):
                os.makedirs(out, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with archive.open(info) as source, open(out, "wb") as handle:
                shutil.copyfileobj(source, handle)


def _unpack(entry):
    common.ensure_dir(PACKAGES)
    zip_path = os.path.join(PACKAGES, "%s-%s.zip" % (entry["id"], entry["version"]))
    with open(zip_path, "wb") as handle:
        handle.write(_get(entry["url"]))
    extract_zip(zip_path, HOME_ADDONS, entry["id"])
    try:
        os.remove(zip_path)
    except OSError:
        pass


def install(targets, on_progress=None, cancelled=None):
    """Install the targets and all they need. Returns (installed ids, compiled ids left for Kodi, failures)."""
    index = load_index()
    entries, missing, asleep = plan(targets, index)
    failures = dict((m, "not listed in any repository on this device") for m in missing)
    compiled = [e["id"] for e in entries if e["compiled"]]
    todo = [e for e in entries if not e["compiled"]]
    unpacked = []
    for number, entry in enumerate(todo):
        if cancelled and cancelled():
            break
        if on_progress:
            on_progress(number, len(todo), entry["id"])
        try:
            _unpack(entry)
            unpacked.append(entry["id"])
        except Exception as exc:
            failures[entry["id"]] = str(exc)
            common.log("silent: %s failed: %r" % (entry["id"], exc))
    if unpacked:
        xbmc.executebuiltin("UpdateLocalAddons", True)
        xbmc.Monitor().waitForAbort(3)
    # Kodi notices new folders a little after UpdateLocalAddons returns and will not switch on an add-on it
    # has not noticed yet, so enable_all waits for each one. Dependencies were unpacked first.
    enable_all(asleep + unpacked, seconds=90)
    for addon_id in unpacked:
        if not _on(addon_id):
            failures.setdefault(addon_id, "unpacked but Kodi did not switch it on")
    installed = [a for a in unpacked if a not in failures]
    return installed, compiled, failures
