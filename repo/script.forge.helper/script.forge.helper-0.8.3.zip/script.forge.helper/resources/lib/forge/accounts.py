# -*- coding: utf-8 -*-
"""Account hub: sign in once, keep credentials in one file, push them to add-ons."""
import time

import xbmc
import xbmcgui

from . import common, connectors

STORE = "accounts.json"
SERVICES = ("trakt", "rd", "pm", "youtube", "keys")
LABELS = {"trakt": "Trakt", "rd": "Real-Debrid", "pm": "Premiumize", "youtube": "YouTube API", "keys": "Metadata API keys"}
USER_AGENT = "Forge Helper/0.1 (Kodi)"
TIMEOUT = 20
RD_OPEN_SOURCE_CLIENT = "X245A4XAIBGVM"  # Real-Debrid's published client id for open source apps
TRAKT_API = "https://api.trakt.tv/"
RD_OAUTH = "https://api.real-debrid.com/oauth/v2/"
TRAKT_REFRESH_MARGIN = 2 * 60 * 60


# -- storage ---------------------------------------------------------------
def load():
    data = common.read_json(common.data_file(STORE))
    for service in SERVICES:
        data.setdefault(service, {})
    return data


def save(data):
    common.write_json(common.data_file(STORE), data)


def get(service):
    return load().get(service, {})


_changed = False


def put(service, account, push=True):
    global _changed
    data = load()
    if data.get(service) != account:
        _changed = True
    data[service] = account
    save(data)
    if push:
        push_service(service)


def refresh_skin(only_if_changed=True):
    """Reload the skin so widgets pick up new or updated accounts."""
    global _changed
    if only_if_changed and not _changed:
        return False
    _changed = False
    xbmc.executebuiltin("ReloadSkin()")
    return True


def is_signed_in(service):
    account = get(service)
    if service == "youtube":
        return bool(account.get("api_key"))
    if service == "keys":
        return any(account.values())
    return bool(account.get("token"))


def status(service):
    account = get(service)
    if service == "youtube":
        return "API key set" if account.get("api_key") else "Not set"
    if service == "keys":
        names = [k for k, v in sorted(account.items()) if v]
        return ", ".join(names) if names else "None set"
    if not account.get("token"):
        return "Not signed in"
    return "Signed in as %s" % account["user"] if account.get("user") else "Signed in"


# -- pushing ---------------------------------------------------------------
def push_service(service, quiet=True):
    account = get(service)
    results = []
    for connector in connectors.installed():
        if not connector.supports(service):
            continue
        try:
            done = connector.push(service, account)
            results.append((connector.name, "updated" if done else "nothing to send"))
            if done and connector.after_push.get(service):
                xbmc.executebuiltin(connector.after_push[service])  # e.g. make the add-on re-sync watched status
        except Exception as exc:
            common.log("push %s -> %s failed: %r" % (service, connector.addon_id, exc))
            results.append((connector.name, "failed: %s" % exc))
    if not quiet:
        _report(LABELS[service], results)
    return results


def push_all(report=False):
    lines = []
    for service in SERVICES:
        if not is_signed_in(service):
            continue
        for name, outcome in push_service(service):
            lines.append("%s -> %s: %s" % (LABELS[service], name, outcome))
    if report:
        if lines:
            refresh_skin(only_if_changed=False)
        common.ok("[CR]".join(lines) if lines else "Nothing to push yet. Sign in to a service first, and make sure the add-ons are installed.", "Push to add-ons")
    return lines


def _report(heading, results):
    if not results:
        common.ok("No installed add-on uses this service yet. It will be pushed automatically once one is installed.", heading)
        return
    common.ok("[CR]".join("%s: %s" % pair for pair in results), heading)


# -- importing -------------------------------------------------------------
def import_from_addon(service):
    """Copy credentials already present in an add-on into the hub, then fan them out."""
    candidates = []
    for connector in connectors.installed():
        if connector.supports(service):
            try:
                account = connector.pull(service)
            except Exception as exc:
                common.log("pull %s <- %s failed: %r" % (service, connector.addon_id, exc))
                continue
            if account.get("token") or account.get("api_key") or (service == "keys" and account):
                candidates.append((connector, account))
    if not candidates:
        common.ok("No installed add-on has %s credentials to import." % LABELS[service])
        return False
    choice = 0
    if len(candidates) > 1:
        choice = common.select("Import %s from" % LABELS[service], [c.name for c, _ in candidates])
        if choice < 0:
            return False
    connector, account = candidates[choice]
    merged = dict(get(service))
    merged.update(account)
    put(service, merged)
    common.notify("%s imported from %s" % (LABELS[service], connector.name))
    return True


def delegate_connector(service):
    """An installed add-on that can run this service's code sign-in itself, if any."""
    for connector in connectors.installed():
        if connector.supports(service) and connector.sign_in.get(service):
            return connector
    return None


def delegated_sign_in(service):
    """Run an add-on's own code sign-in, then copy the result into the hub and on to the others.

    Used where a device-code flow needs a client id registered to that add-on
    (Premiumize), so the hub cannot run the flow under its own name.
    """
    connector = delegate_connector(service)
    if not connector:
        return False
    before = connector.pull(service).get("token", "")
    xbmc.executebuiltin(connector.sign_in[service])
    monitor = xbmc.Monitor()
    deadline = time.time() + 12 * 60
    token = ""
    while time.time() < deadline and not monitor.waitForAbort(2):
        token = connector.pull(service).get("token", "")
        if token and token != before:
            break
        token = ""
    if not token:
        common.notify("%s sign-in was not completed" % LABELS[service])
        return False
    monitor.waitForAbort(3)  # let the add-on finish writing the account id
    wait_for_addon_dialogs()
    put(service, connector.pull(service))
    common.notify("%s: %s" % (LABELS[service], status(service)))
    return True


# -- device code flows -----------------------------------------------------
def _poll(heading, message, expires_in, interval, attempt):
    """Show a progress dialog and call attempt() every `interval` seconds until it returns a value."""
    dialog = xbmcgui.DialogProgress()
    dialog.create(heading, message)
    monitor = xbmc.Monitor()
    start = time.time()
    result = None
    try:
        while not dialog.iscanceled() and not monitor.abortRequested():
            elapsed = time.time() - start
            if elapsed >= expires_in:
                break
            dialog.update(int(100 * elapsed / expires_in), message)
            if monitor.waitForAbort(max(int(interval), 1)):
                break
            if dialog.iscanceled():
                break
            result = attempt()
            if result is not None:
                break
    finally:
        dialog.close()
    return result


def trakt_headers(client_id, token=None):
    headers = {"Content-Type": "application/json", "trakt-api-version": "2", "trakt-api-key": client_id, "User-Agent": USER_AGENT}
    if token:
        headers["Authorization"] = "Bearer %s" % token
    return headers


def trakt_set_app_keys():
    account = dict(get("trakt"))
    common.ok("This is a one-time step, not an error. Trakt no longer accepts the keys built into add-ons, so each person needs their own free API app.[CR][CR]"
              "1. On a computer, open developer.trakt.tv, go to My Apps and connect GitHub (one time).[CR]"
              "2. Create an app with any name and copy its Client ID.[CR]"
              "3. Enter the Client ID on the next screen (Ctrl+V pastes). New apps have no Client Secret, so leave that one blank.", "Trakt: one-time setup")
    client_id = common.text_input("Trakt Client ID", account.get("client_id", "")).strip()
    if not client_id:
        return False
    client_secret = common.text_input("Client Secret (leave blank if Trakt shows 'Not issued')", account.get("client_secret", "")).strip()
    if (client_id, client_secret) != (account.get("client_id"), account.get("client_secret", "")):
        account = {"client_id": client_id}  # old tokens belong to the old app
        if client_secret:
            account["client_secret"] = client_secret
    put("trakt", account, push=False)
    return True


def _trakt_app_body(account, **fields):
    """OAuth request body. The secret is sent only by older apps that were issued one."""
    body = dict(fields, client_id=account["client_id"])
    if account.get("client_secret"):
        body["client_secret"] = account["client_secret"]
    return body


# The Forge's own Trakt app, so sign-in is just the on-screen code for everyone. A Client ID is not a
# secret: Trakt apps sign in without a Client Secret. This is the Production app (granted 23 November 2026),
# which anyone may sign in to. A personal Client ID can still be entered by hand.
FORGE_TRAKT_CLIENT_ID = "vhGuwrl8DofRRGlqkUH3bPvjRQG4Z4szDmGNjeggjOU"
# The earlier Development app, which only its owner could sign in to. A sign-in made with it keeps working
# (its tokens refresh against it); the next sign-in moves to the Production app.
FORGE_TRAKT_OLD_CLIENT_IDS = ("KcNaOgjUn6hLg6USkj2I001azuEr5IcX4ISqcT-cDCg",)


def trakt_sign_in():
    import requests

    account = dict(get("trakt"))
    if FORGE_TRAKT_CLIENT_ID and (not account.get("client_id") or account.get("client_id") in FORGE_TRAKT_OLD_CLIENT_IDS):
        # nothing is saved until Trakt hands over tokens, so an existing sign-in survives a cancelled attempt
        account = {"client_id": FORGE_TRAKT_CLIENT_ID}
    if not account.get("client_id"):
        if not trakt_set_app_keys():
            return False
        account = dict(get("trakt"))
    client_id = account["client_id"]
    response = requests.post(TRAKT_API + "oauth/device/code", json={"client_id": client_id}, headers=trakt_headers(client_id), timeout=TIMEOUT)
    if response.status_code != 200:
        common.ok("Trakt rejected the Client ID (HTTP %s). Check the app keys and try again." % response.status_code)
        return False
    codes = response.json()
    message = "Go to [B]%s[/B][CR]and enter the code [B]%s[/B]" % (codes["verification_url"], codes["user_code"])

    def attempt():
        poll = requests.post(TRAKT_API + "oauth/device/token", json=_trakt_app_body(account, code=codes["device_code"]), headers=trakt_headers(client_id), timeout=TIMEOUT)
        return poll.json() if poll.status_code == 200 else None

    tokens = _poll("Trakt sign-in", message, int(codes.get("expires_in", 600)), int(codes.get("interval", 5)), attempt)
    if not tokens:
        common.notify("Trakt sign-in was not completed")
        return False
    _store_trakt_tokens(account, tokens)
    account = dict(get("trakt"))
    try:
        user = requests.get(TRAKT_API + "users/settings", headers=trakt_headers(client_id, account["token"]), timeout=TIMEOUT).json()
        account["user"] = str(user["user"]["username"])
    except Exception as exc:
        common.log("trakt username lookup failed: %r" % exc)
    put("trakt", account)
    common.notify("Trakt: %s" % status("trakt"))
    return True


def _store_trakt_tokens(account, tokens):
    account = dict(account)
    account["token"] = tokens["access_token"]
    account["refresh"] = tokens["refresh_token"]
    account["expires"] = str(time.time() + int(tokens.get("expires_in") or 86400))
    put("trakt", account, push=False)


def trakt_refresh():
    import requests

    account = dict(get("trakt"))
    if not all(account.get(k) for k in ("client_id", "refresh")):
        return False
    body = _trakt_app_body(account, refresh_token=account["refresh"], grant_type="refresh_token")
    if account.get("client_secret"):
        body["redirect_uri"] = "urn:ietf:wg:oauth:2.0:oob"
    response = requests.post(TRAKT_API + "oauth/token", json=body, headers=trakt_headers(account["client_id"]), timeout=TIMEOUT)
    if response.status_code != 200:
        common.log("trakt refresh failed: HTTP %s" % response.status_code)
        return False
    _store_trakt_tokens(account, response.json())
    push_service("trakt")
    return True


def rd_sign_in():
    import requests

    codes = requests.get(RD_OAUTH + "device/code", params={"client_id": RD_OPEN_SOURCE_CLIENT, "new_credentials": "yes"}, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT).json()
    message = "Go to [B]%s[/B][CR]and enter the code [B]%s[/B]" % (codes.get("verification_url", "real-debrid.com/device"), codes["user_code"])

    def attempt():
        poll = requests.get(RD_OAUTH + "device/credentials", params={"client_id": RD_OPEN_SOURCE_CLIENT, "code": codes["device_code"]}, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT)
        data = poll.json() if poll.status_code == 200 else {}
        return data if data.get("client_secret") else None

    credentials = _poll("Real-Debrid sign-in", message, int(codes.get("expires_in", 600)), int(codes.get("interval", 5)), attempt)
    if not credentials:
        common.notify("Real-Debrid sign-in was not completed")
        return False
    token = requests.post(RD_OAUTH + "token", data={"client_id": credentials["client_id"], "client_secret": credentials["client_secret"], "code": codes["device_code"],
                                                    "grant_type": "http://oauth.net/grant_type/device/1.0"}, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT).json()
    if "access_token" not in token:
        common.ok("Real-Debrid did not return a token: %s" % token.get("error", "unknown error"))
        return False
    account = {"client_id": credentials["client_id"], "client_secret": credentials["client_secret"], "token": token["access_token"], "refresh": token["refresh_token"]}
    try:
        info = requests.get("https://api.real-debrid.com/rest/1.0/user", headers={"Authorization": "Bearer %s" % account["token"], "User-Agent": USER_AGENT}, timeout=TIMEOUT).json()
        account["user"] = str(info["username"])
    except Exception as exc:
        common.log("rd username lookup failed: %r" % exc)
    put("rd", account)
    common.notify("Real-Debrid: %s" % status("rd"))
    return True


def pm_set_key():
    import requests

    common.ok("Enter the API key shown on premiumize.me/account. If an add-on is already signed in to Premiumize you can use 'Import from an add-on' instead.", "Premiumize")
    key = common.text_input("Premiumize API key", get("pm").get("token", ""))
    if not key:
        return False
    account = {"token": key.strip()}
    try:
        info = requests.get("https://www.premiumize.me/api/account/info", params={"apikey": account["token"]}, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT).json()
        if info.get("status") != "success":
            if not common.confirm("Premiumize did not accept that key (%s). Save it anyway?" % info.get("message", "no details")):
                return False
        else:
            account["user"] = str(info.get("customer_id", ""))
    except Exception as exc:
        common.log("pm verification failed: %r" % exc)
    put("pm", account)
    common.notify("Premiumize: %s" % status("pm"))
    return True


def youtube_set_keys():
    account = dict(get("youtube"))
    common.ok("Enter the three values from your own Google Cloud project (YouTube Data API v3): API key, OAuth client ID and client secret.", "YouTube API")
    for field, heading in (("api_key", "YouTube API key"), ("client_id", "YouTube client ID"), ("client_secret", "YouTube client secret")):
        value = common.text_input(heading, account.get(field, ""))
        if value:
            account[field] = value.strip()
    if not account.get("api_key"):
        return False
    put("youtube", account)
    common.notify("YouTube API keys saved")
    return True


# The Forge's own TMDb key (v3). Fen Light's built-in key no longer works, and without a working key its
# lists come back empty. With this filled in, setup uses it without asking; anyone can still enter their own key.
FORGE_TMDB_KEY = "2438380b1d66d94350c12f810a2aca2f"


def wait_for_addon_dialogs(limit=90):
    """Wait until an add-on's own pop-up (a "success" box, say) has been closed. Opening our next question
    while it is still up means the button press that closes it answers ours as well."""
    monitor = xbmc.Monitor()
    deadline = time.time() + limit
    clear = 0
    while time.time() < deadline and clear < 2:
        clear = clear + 1 if xbmcgui.getCurrentWindowDialogId() < 13000 else 0  # add-on windows are 13000 and up
        if monitor.waitForAbort(0.5):
            return


def ensure_tmdb_key(ask=True):
    """Make sure a TMDb key is saved and pushed. Returns True when one is in place."""
    account = dict(get("keys"))
    if account.get("tmdb"):
        return True
    if FORGE_TMDB_KEY:
        account["tmdb"] = FORGE_TMDB_KEY
        put("keys", account)
        return True
    if not ask:
        return False
    wait_for_addon_dialogs()
    # An OK box then the keyboard, not a yes/no question: a stray button press cannot skip the step by accident
    common.ok("Home rows stay empty without a free TMDb key.[CR]"
              "Get one at themoviedb.org under Settings, API.[CR]Type it on the next screen, or leave it blank to skip.",
              "Forge setup: TMDb key")
    while True:
        value = common.text_input("TMDb API key (v3)").strip()
        if value:
            break
        if common.confirm("No key entered. Skip this step? Home rows will stay empty until a key is added.",
                          "Forge setup: TMDb key"):
            return False
    account["tmdb"] = value
    put("keys", account)
    return True


KEY_FIELDS = (("fanarttv", "Fanart.tv client key"), ("mdblist", "MDBList API key"), ("omdb", "OMDb API key"), ("tmdb", "TMDb API key (v3)"))


def keys_set(field):
    account = dict(get("keys"))
    heading = dict(KEY_FIELDS)[field]
    value = common.text_input(heading, account.get(field, ""))
    if value == "" and account.get(field):
        if not common.confirm("Clear the saved %s?" % heading):
            return False
    account[field] = value.strip()
    put("keys", account)
    return True


def sign_out(service):
    if not common.confirm("Remove %s from The Forge? Add-ons keep whatever was already pushed to them until you sign out there." % LABELS[service]):
        return False
    account = get(service)
    kept = {k: account[k] for k in ("client_id", "client_secret") if service == "trakt" and account.get(k)}
    put(service, kept, push=False)
    return True


# -- background sync -------------------------------------------------------
def background_sync():
    """Keep Trakt tokens aligned.

    Trakt refresh tokens are single use, so whichever add-on refreshes first
    strands the others. Each pass adopts the newest token found anywhere and
    pushes it to everything else, then refreshes centrally when expiry is near.
    """
    account = dict(get("trakt"))
    if not account.get("token"):
        return
    newest, source = _expires(account), None
    for connector in connectors.installed():
        if not connector.supports("trakt"):
            continue
        try:
            theirs = connector.pull("trakt")
        except Exception as exc:
            common.log("sync pull %s failed: %r" % (connector.addon_id, exc))
            continue
        if theirs.get("client_id") and theirs.get("client_id") != account.get("client_id"):
            continue  # signed in under a different Trakt app; leave it alone
        if theirs.get("token") and _expires(theirs) > newest + 60:
            newest, source = _expires(theirs), theirs
    if source:
        account.update({k: source[k] for k in ("token", "refresh", "expires") if source.get(k)})
        put("trakt", account)
        common.log("trakt: adopted a newer token from an add-on and re-pushed it")
    elif _expires(account) - time.time() < TRAKT_REFRESH_MARGIN:
        if trakt_refresh():
            common.log("trakt: token refreshed centrally")


def _expires(account):
    try:
        return float(account.get("expires") or 0)
    except (TypeError, ValueError):
        return 0.0
