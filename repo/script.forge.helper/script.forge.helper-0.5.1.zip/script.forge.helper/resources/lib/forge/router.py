# -*- coding: utf-8 -*-
from urllib.parse import parse_qsl

from . import common


def run(argv):
    params = {}
    for arg in argv:
        params.update(dict(parse_qsl(arg, keep_blank_values=True)))
    mode = params.get("mode", "main")
    try:
        _dispatch(mode, params)
    except Exception as exc:
        import traceback

        common.log("mode %s failed: %s" % (mode, traceback.format_exc()))
        common.ok("Something went wrong in '%s':[CR]%s" % (mode, exc))


def _dispatch(mode, params):
    if mode == "main":
        from . import menus

        return menus.main()
    if mode == "accounts":
        from . import menus

        return menus.accounts_menu()
    if mode == "push_accounts":
        from . import accounts

        return accounts.push_all(report=True)
    if mode == "setup":
        from . import setup

        return setup.run(first_run=params.get("first") == "1")
    if mode == "volume_amp":
        from . import volume

        return volume.menu()
    if mode == "checklist":
        from . import checklist

        return checklist.menu()
    if mode == "fenlight_tweaks":
        from . import fenlight_tweaks

        return fenlight_tweaks.apply_all(report=True)
    if mode == "update":
        from . import update

        return update.run()
    if mode == "rollback":
        from . import update

        return update.rollback()
    if mode == "refresh_skin":
        import xbmc

        xbmc.executebuiltin("ReloadSkin()")
        return common.notify("Skin refreshed")
    if mode == "picker":
        from . import picker

        return picker.menu()
    if mode == "picker_shuffle":
        from . import picker

        return picker.find(open_results=True)
    if mode == "install_player":
        from . import picker

        return picker.install_fenlight_player()
    common.log("unknown mode: %s" % mode)
