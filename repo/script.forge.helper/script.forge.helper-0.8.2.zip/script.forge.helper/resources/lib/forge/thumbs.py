# -*- coding: utf-8 -*-
"""Clear out old artwork from Kodi's picture cache.

Kodi keeps a copy of every poster, fanart and thumbnail it has ever shown and never removes one by itself, so
the cache only grows. This removes the pictures that have not been shown for a week. Nothing is lost: a picture
that is needed again is simply fetched again.

Removal goes through Kodi's own texture list, so its database and the files stay in step. Files in the cache
folder that Kodi no longer knows about are removed too, by their age.
"""
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

from . import common, setup

KEEP_DAYS = 7
DAY = 24 * 60 * 60
RUN_EVERY = DAY


def _folder():
    return xbmcvfs.translatePath("special://thumbnails/")


def _when(text):
    """Kodi writes times as '2026-11-20 21:14:03'. Returns seconds since 1970, or 0 when there is no time."""
    try:
        return time.mktime(time.strptime((text or "")[:19], "%Y-%m-%d %H:%M:%S"))
    except (ValueError, OverflowError):
        return 0


def _last_used(texture, path):
    used = max([_when(size.get("lastused")) for size in texture.get("sizes") or []] or [0])
    if used:
        return used
    try:  # never recorded as used: go by when the file was written
        return os.path.getmtime(path)
    except OSError:
        return _when(texture.get("lasthashcheck"))


def _size(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def clean(progress=None, cancelled=None):
    """Remove cached pictures not shown for KEEP_DAYS. Returns {'removed', 'kept', 'freed', 'stopped'}."""
    folder = _folder()
    cutoff = time.time() - KEEP_DAYS * DAY
    result = common.jsonrpc("Textures.GetTextures", {"properties": ["cachedurl", "lasthashcheck", "sizes"]}) or {}
    textures = result.get("textures") or []
    known, old = set(), []
    for texture in textures:
        cached = (texture.get("cachedurl") or "").replace("\\", "/")
        if not cached:
            continue
        known.add(cached.lower())
        path = os.path.join(folder, *cached.split("/"))
        if _last_used(texture, path) < cutoff:
            old.append((texture["textureid"], path))
    removed = freed = 0
    stopped = False
    for position, (texture_id, path) in enumerate(old):
        if cancelled and cancelled():
            stopped = True
            break
        if progress and position % 25 == 0:
            progress(int(90.0 * position / max(len(old), 1)), "Removing old pictures: %d of %d" % (position, len(old)))
        size = _size(path)
        if common.jsonrpc("Textures.RemoveTexture", {"textureid": texture_id}) == "OK":
            removed += 1
            freed += size
    # files Kodi no longer lists (left behind by crashes or older versions), by age
    if not stopped and textures:
        if progress:
            progress(92, "Checking for leftover files")
        for parent, _, files in os.walk(folder):
            for name in files:
                path = os.path.join(parent, name)
                relative = os.path.relpath(path, folder).replace("\\", "/").lower()
                if relative in known or not name.lower().endswith((".jpg", ".png", ".dds")):
                    continue
                try:
                    if os.path.getmtime(path) < cutoff:
                        size = _size(path)
                        os.remove(path)
                        removed += 1
                        freed += size
                except OSError:
                    pass
    setup.save_state(thumbs_cleaned_at=time.time())
    outcome = {"removed": removed, "kept": max(len(textures) - len(old), 0), "freed": freed, "stopped": stopped}
    common.log("thumbnails: %(removed)d removed, %(kept)d kept, %(freed)d bytes freed" % outcome)
    return outcome


def _megabytes(count):
    return "%.1f GB" % (count / 1073741824.0) if count >= 1073741824 else "%.0f MB" % (count / 1048576.0)


def run():
    """From the helper's screen: explain, clean with a progress bar, report."""
    if not common.confirm("Remove cached posters, fanart and thumbnails that have not been shown in the last %d days?"
                          "[CR][CR]Nothing is lost. Any picture that is needed again is downloaded again, so the "
                          "first visit to a rarely used list may load its art a little slower." % KEEP_DAYS,
                          "Clean up old thumbnails"):
        return None
    common.not_busy()
    dialog = xbmcgui.DialogProgress()
    dialog.create("Clean up old thumbnails", "Reading the picture cache")
    try:
        outcome = clean(progress=lambda percent, text: dialog.update(percent, text), cancelled=dialog.iscanceled)
    except Exception as exc:
        common.log("thumbnails: clean up failed: %r" % exc)
        dialog.close()
        return common.ok("The clean up did not finish: %s" % exc, "Clean up old thumbnails")
    dialog.close()
    if not outcome["removed"]:
        return common.ok("Nothing to remove. All %d cached pictures were shown in the last %d days."
                         % (outcome["kept"], KEEP_DAYS), "Clean up old thumbnails")
    return common.ok("%sRemoved %d pictures and freed %s.[CR]Kept %d that were shown in the last %d days.[CR][CR]"
                     "The helper also does this by itself once a day." % (
                         "Stopped early. " if outcome["stopped"] else "", outcome["removed"],
                         _megabytes(outcome["freed"]), outcome["kept"], KEEP_DAYS), "Clean up old thumbnails")


def due():
    return time.time() - float(setup.state().get("thumbs_cleaned_at") or 0) >= RUN_EVERY


def background():
    """Daily, from the service, and only while nothing is playing."""
    if due() and not xbmc.Player().isPlaying():
        clean()
