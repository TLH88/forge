# -*- coding: utf-8 -*-
"""Movie sets (TMDb collections): rows of sets, the next movie to watch in each, and the prompt near the end
of a movie that offers the next one.

Everything fetched from TMDb is cached in the helper's data folder, so home rows open from disk. What has been
watched is read from Fen Light's own databases, the same source as the ticks on its cards.
"""
import os
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote_plus

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import accounts, common

TMDB = "https://api.themoviedb.org/3/"
IMAGE = "https://image.tmdb.org/t/p/%s%s"
FEN = "plugin.video.fenlight"
FEN_DATABASES = "special://profile/addon_data/%s/databases/" % FEN
CACHE_FILE = "sets_cache.json"
WEEK = 7 * 24 * 60 * 60
MONTH = 30 * 24 * 60 * 60
POPULAR_PAGES = 5
POPULAR_LIMIT = 40
RECENT_DAYS = 180  # the two personal rows only show sets you have watched something from this recently
MINE_LIMIT = 40
PROMPT_AT = 0.95
PROMPT_MIN_LENGTH = 20 * 60  # shorter videos are not feature films

_cache = None


# -- cache -----------------------------------------------------------------------
def _load():
    global _cache
    if _cache is None:
        _cache = common.read_json(common.data_file(CACHE_FILE), {}) or {}
        for key in ("movies", "sets", "lists"):
            _cache.setdefault(key, {})
    return _cache


def _save():
    if _cache is not None:
        common.write_json(common.data_file(CACHE_FILE), _cache)


# -- TMDb ------------------------------------------------------------------------
def _key():
    return accounts.get("keys").get("tmdb") or accounts.FORGE_TMDB_KEY


def _tmdb(path, **params):
    import requests

    params["api_key"] = _key()
    params.setdefault("language", "en-US")
    for attempt in range(4):
        response = requests.get(TMDB + path, params=params, timeout=20, headers={"User-Agent": "Kodi Forge Helper"})
        if response.status_code != 429:  # 429: TMDb asking for a pause, which a burst of lookups can trigger
            break
        time.sleep(min(float(response.headers.get("Retry-After") or 1.5), 5.0) + 0.5 * attempt)
    response.raise_for_status()
    return response.json()


def set_of_movie(tmdb_id, save=True):
    """{'id', 'name', 'poster', 'fanart'} for the set a movie belongs to, or {} when it is in none."""
    cache = _load()
    key = str(tmdb_id)
    entry = cache["movies"].get(key)
    if entry and time.time() - entry.get("at", 0) < MONTH:
        return entry.get("set") or {}
    try:
        found = _tmdb("movie/%s" % key).get("belongs_to_collection") or {}
    except Exception as exc:
        common.log("sets: movie %s lookup failed: %r" % (key, exc))
        return (entry or {}).get("set") or {}
    info = {}
    if found.get("id"):
        info = {"id": found["id"], "name": found.get("name") or "", "poster": found.get("poster_path") or "",
                "fanart": found.get("backdrop_path") or ""}
    cache["movies"][key] = {"at": time.time(), "set": info}
    if save:
        _save()
    return info


def collection(set_id, save=True):
    """A set with its released movies in release order: {'id', 'name', 'poster', 'fanart', 'plot', 'parts'}."""
    cache = _load()
    key = str(set_id)
    entry = cache["sets"].get(key)
    if entry and time.time() - entry.get("at", 0) < WEEK:
        return entry["data"]
    try:
        data = _tmdb("collection/%s" % key)
    except Exception as exc:
        common.log("sets: collection %s lookup failed: %r" % (key, exc))
        return entry["data"] if entry else {}
    today = time.strftime("%Y-%m-%d")
    parts = [{"id": p["id"], "title": p.get("title") or "", "date": p.get("release_date") or "",
              "poster": p.get("poster_path") or "", "fanart": p.get("backdrop_path") or "",
              "plot": p.get("overview") or "", "rating": p.get("vote_average") or 0}
             for p in data.get("parts") or [] if p.get("id") and p.get("release_date") and p["release_date"] <= today]
    parts.sort(key=lambda p: p["date"])
    result = {"id": data.get("id") or int(key), "name": data.get("name") or "", "poster": data.get("poster_path") or "",
              "fanart": data.get("backdrop_path") or "", "plot": data.get("overview") or "", "parts": parts}
    cache["sets"][key] = {"at": time.time(), "data": result}
    if save:
        _save()
    return result


def _many(function, keys):
    """Run lookups side by side; the cache is written once afterwards."""
    keys = list(keys)
    if not keys:
        return []
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda key: function(key, save=False), keys))
    _save()
    return results


# -- what has been watched ---------------------------------------------------------
class WatchedUnavailable(Exception):
    """Fen Light's watched records exist but could not be read just now (it locks them while it syncs)."""


def watched():
    """TMDb id (text) -> when it was last watched, from Fen Light's local and Trakt-synced databases.

    Raises WatchedUnavailable when a database is there but cannot be read, so a busy moment is never mistaken
    for "nothing watched" and the set rows are not emptied by it.
    """
    seen = {}
    folder = xbmcvfs.translatePath(FEN_DATABASES)
    for name in ("watched.db", "traktcache.db"):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        rows, problem = None, None
        for attempt in range(3):
            try:
                con = sqlite3.connect("file:%s?mode=ro" % path.replace("\\", "/"), uri=True, timeout=5)
                try:
                    rows = con.execute("SELECT media_id, last_played FROM watched WHERE db_type = ?", ("movie",)).fetchall()
                finally:
                    con.close()
                break
            except Exception as exc:
                problem = exc
                time.sleep(1.5)
        if rows is None:
            common.log("sets: could not read %s: %r" % (name, problem))
            raise WatchedUnavailable(name)
        for media_id, last_played in rows:
            key = str(media_id)
            if str(last_played or "") >= seen.get(key, ""):
                seen[key] = str(last_played or "")
    return seen


# -- the lists ---------------------------------------------------------------------
def popular_sets(refresh=False):
    """Sets found among TMDb's popular and top rated movies. Rebuilt weekly; the first build takes a moment."""
    cache = _load()
    entry = cache["lists"].get("popular")
    if entry and not refresh and time.time() - entry.get("at", 0) < WEEK:
        return entry["sets"]
    movie_ids = []
    try:
        for kind in ("movie/popular", "movie/top_rated"):
            for page in range(1, POPULAR_PAGES + 1):
                for movie in _tmdb(kind, page=page).get("results") or []:
                    if movie.get("id") and movie["id"] not in movie_ids:
                        movie_ids.append(movie["id"])
    except Exception as exc:
        common.log("sets: popular movies not available: %r" % exc)
        if not movie_ids:
            return entry["sets"] if entry else []
    found, order = {}, []
    for info in _many(set_of_movie, movie_ids):
        if info and info["id"] not in found:
            found[info["id"]] = info
            order.append(info["id"])
    sets = [found[set_id] for set_id in order][:POPULAR_LIMIT]
    cache["lists"]["popular"] = {"at": time.time(), "sets": sets}
    _save()
    return sets


def my_sets(seen=None):
    """Sets holding at least one movie you have watched, most recently watched first."""
    seen = watched() if seen is None else seen
    recent = sorted(seen, key=lambda key: seen[key], reverse=True)
    cutoff = time.time() - recent_days() * 24 * 60 * 60
    found, order = {}, []
    for key, info in zip(recent, _many(set_of_movie, recent)):
        if info and info["id"] not in found:
            # the list runs newest first, so the first movie met for a set is the last one watched from it
            watched_at = _when(seen[key])
            found[info["id"]] = dict(info, last=seen[key])
            if not watched_at or watched_at >= cutoff:  # no readable date: keep it rather than hide it
                order.append(info["id"])
    return [found[set_id] for set_id in order][:MINE_LIMIT]


def recent_days():
    options = common.read_json(common.data_file("options.json"), {}) or {}
    try:
        return max(int(options.get("sets_recent_days", RECENT_DAYS)), 1)
    except (TypeError, ValueError):
        return RECENT_DAYS


def _when(text):
    """Fen Light writes '2026-11-20 21:14:03' for its own records and '2026-11-20T21:14:03.000Z' for Trakt's."""
    try:
        return time.mktime(time.strptime(str(text or "")[:19].replace("T", " "), "%Y-%m-%d %H:%M:%S"))
    except (ValueError, OverflowError):
        return 0


def search_sets(query):
    """Sets whose name matches, straight from TMDb."""
    query = (query or "").strip()
    if not query:
        return []
    found = _tmdb("search/collection", query=query, page=1).get("results") or []
    return [{"id": item["id"], "name": item.get("name") or "", "poster": item.get("poster_path") or "",
             "fanart": item.get("backdrop_path") or ""} for item in found if item.get("id")]


def continue_sets(seen=None, started=None):
    """For every set you have started and not finished: (set, next unwatched movie), most recent first."""
    seen = watched() if seen is None else seen
    started = my_sets(seen) if started is None else started
    result = []
    for info, data in zip(started, _many(collection, [info["id"] for info in started])):
        parts = (data or {}).get("parts") or []
        unwatched = [part for part in parts if str(part["id"]) not in seen]
        if unwatched and len(unwatched) < len(parts):
            result.append((data, unwatched[0]))
    return result


def next_in_set(tmdb_id):
    """(set, the movie released after this one in its set), or (None, None)."""
    info = set_of_movie(tmdb_id)
    if not info:
        return None, None
    data = collection(info["id"])
    parts = (data or {}).get("parts") or []
    ids = [str(part["id"]) for part in parts]
    if str(tmdb_id) not in ids or ids.index(str(tmdb_id)) + 1 >= len(parts):
        return None, None
    return data, parts[ids.index(str(tmdb_id)) + 1]


LOCK_FILE = "sets.lock"
LOCK_LIFE = 5 * 60


def _busy():
    """True while another part of the helper is working the lists out (the lock goes stale after five minutes)."""
    try:
        return time.time() - os.path.getmtime(common.data_file(LOCK_FILE)) < LOCK_LIFE
    except OSError:
        return False


def refresh_lists():
    """Work out Your Movie Sets and Continue Your Sets and keep the answers on disk, so the home rows open at
    once. Run by the helper's service at start-up, after playback and every so often. One run at a time: three
    at once only trip TMDb's rate limit. Returns False when the watched records could not be read; the lists
    already on disk are left alone in that case."""
    global _cache
    if _busy():
        return False
    lock = common.data_file(LOCK_FILE)
    with open(lock, "w") as handle:
        handle.write(str(time.time()))
    try:
        _cache = None  # pick up whatever another part of the helper saved since this one last looked
        try:
            seen = watched()
        except WatchedUnavailable:
            return False
        started = my_sets(seen)
        rows = [{"set": {key: data.get(key) for key in ("id", "name", "poster", "fanart")}, "part": part}
                for data, part in continue_sets(seen, started)]
        cache = _load()
        cache["lists"]["mine"] = {"at": time.time(), "sets": started}
        cache["lists"]["continue"] = {"at": time.time(), "rows": rows}
        _save()
        common.log("sets: %d watched movies, %d sets started, %d to continue" % (len(seen), len(started), len(rows)))
        return True
    finally:
        try:
            os.remove(lock)
        except OSError:
            pass


def _saved(name, key):
    """A list the service has prepared. If it is not there yet, or came out empty, wait for a run in progress or
    do one now, so a row is never left empty just because it was asked for at a bad moment."""
    global _cache
    monitor = xbmc.Monitor()
    for _ in range(45):
        _cache = None
        entry = _load()["lists"].get(name)
        if entry and entry.get(key):
            return entry[key]
        if not _busy():
            if refresh_lists():
                _cache = None
                return (_load()["lists"].get(name) or {}).get(key) or []
            if not _busy():
                break
        if monitor.waitForAbort(2):
            break
    return ((_load()["lists"].get(name) or {}).get(key)) or []


# -- paths into Fen Light ------------------------------------------------------------
def set_path(set_id, name):
    return "plugin://%s/?mode=build_movie_list&action=tmdb_movies_sets&key_id=%s&name=%s" % (FEN, set_id, quote_plus(name or "Movie Set"))


def play_path(tmdb_id):
    return "plugin://%s/?mode=playback.media&media_type=movie&tmdb_id=%s" % (FEN, tmdb_id)


def _art(poster, fanart):
    art = {}
    if poster:
        art["poster"] = art["thumb"] = art["icon"] = IMAGE % ("w500", poster)
    if fanart:
        art["fanart"] = art["landscape"] = IMAGE % ("w1280", fanart)
    return art


# -- home rows -----------------------------------------------------------------------
def serve_sets(handle, params):
    """A row of sets. source=mine: sets you have started. Anything else: popular sets."""
    mine = params.get("source") == "mine"
    searching = params.get("mode") == "search_sets"
    xbmcplugin.setPluginCategory(handle, "Your Movie Sets" if mine else "Movie Sets")
    xbmcplugin.setContent(handle, "sets")
    try:
        if searching:
            sets = search_sets(params.get("query"))
        else:
            sets = _saved("mine", "sets") if mine else popular_sets()
    except Exception:
        import traceback

        common.log("sets: row failed: %s" % traceback.format_exc())
        sets = []
    for info in sets[:int(params.get("limit", 40))]:
        li = xbmcgui.ListItem(info["name"], offscreen=True)
        li.setArt(_art(info.get("poster"), info.get("fanart")))
        tag = li.getVideoInfoTag()
        tag.setTitle(info["name"])
        tag.setMediaType("set")
        li.setProperty("forge.tile", "set")
        xbmcplugin.addDirectoryItem(handle, set_path(info["id"], info["name"]), li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def serve_continue(handle, params):
    """The next unwatched movie of every set you have started."""
    xbmcplugin.setPluginCategory(handle, "Continue Your Sets")
    xbmcplugin.setContent(handle, "movies")
    try:
        rows = _saved("continue", "rows")
    except Exception:
        import traceback

        common.log("sets: continue row failed: %s" % traceback.format_exc())
        rows = []
    shown = 0
    for row in rows[:int(params.get("limit", 30))]:
        try:
            data, part = row["set"], row["part"]
            li = xbmcgui.ListItem(part["title"], offscreen=True)
            li.setArt(_art(part.get("poster") or data.get("poster"), part.get("fanart") or data.get("fanart")))
            tag = li.getVideoInfoTag()
            tag.setTitle(part["title"])
            tag.setMediaType("movie")
            tag.setUniqueIDs({"tmdb": str(part["id"])}, "tmdb")
            if part.get("date"):
                tag.setYear(int(part["date"][:4]))
                tag.setPremiered(part["date"])
            if part.get("rating"):
                tag.setRating(float(part["rating"]))
            if part.get("plot"):
                tag.setPlot(part["plot"])
            li.setProperty("tmdb_id", str(part["id"]))
            li.setProperty("belongs_to_collection", "true")
            li.setProperty("forge.set", data.get("name") or "")
            xbmcplugin.addDirectoryItem(handle, play_path(part["id"]), li, False)
            shown += 1
        except Exception:  # one odd entry must not empty the whole row
            import traceback

            common.log("sets: continue item failed: %s" % traceback.format_exc())
    common.log("sets: continue row shows %d of %d" % (shown, len(rows)))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# -- opening a set from the information screen ---------------------------------------
def open_set(params):
    set_id, name = params.get("set_id") or "", ""
    if set_id:
        name = (collection(set_id) or {}).get("name") or ""
    elif params.get("tmdb_id"):
        info = set_of_movie(params["tmdb_id"])
        set_id, name = info.get("id") or "", info.get("name") or ""
    if not set_id:
        common.log("sets: no set for %r" % (params,))
        return common.notify("No movie set found for this title")
    # Kodi refuses to open a window, with an error sound, while any modal dialog is up. Both the helper's own
    # start-up spinner and the information screen are modal, so close them and wait until they are gone.
    monitor = xbmc.Monitor()
    here = xbmc.getInfoLabel("Container.FolderPath")
    if "tmdb_movies_sets" in here and "key_id=%s&" % set_id in here + "&":
        xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
        xbmc.executebuiltin("Dialog.Close(movieinformation,true)")
        return None
    xbmc.executebuiltin("Dialog.Close(busydialognocancel,true)")
    xbmc.executebuiltin("Dialog.Close(movieinformation,true)")
    for _ in range(30):
        if monitor.waitForAbort(0.1):
            return None
        if not xbmc.getCondVisibility("Window.IsActive(busydialognocancel) | Window.IsActive(movieinformation)"):
            break
    common.log("sets: opening set %s (%s)" % (set_id, name))
    xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % set_path(set_id, name))
    return None


# -- "watch the next one?" -------------------------------------------------------------
def enabled():
    options = common.read_json(common.data_file("options.json"), {}) or {}
    return options.get("next_in_set_prompt", True)


def _playing_movie(player):
    """TMDb id of the movie that is playing, or '' for anything else."""
    try:
        tag = player.getVideoInfoTag()
        if tag.getMediaType() != "movie":
            return ""
        return tag.getUniqueID("tmdb") or ""
    except Exception:
        return ""


def watch_playback(player, monitor):
    """Runs for the life of one video. At 95 percent of a movie that has a successor in its set, asks whether
    to watch that next. Later and no answer both do nothing: the movie turns up in Continue Your Sets."""
    if not enabled():
        return
    for _ in range(15):  # the player takes a moment to report what it is showing
        if monitor.waitForAbort(2) or not player.isPlayingVideo():
            return
        tmdb_id = _playing_movie(player)
        if tmdb_id:
            break
    else:
        return
    data, following = next_in_set(tmdb_id)
    if not following:
        return
    while not monitor.waitForAbort(3):
        try:
            if not player.isPlayingVideo() or _playing_movie(player) != tmdb_id:
                return
            total, position = player.getTotalTime(), player.getTime()
        except RuntimeError:
            return
        if total >= PROMPT_MIN_LENGTH and position / total >= PROMPT_AT:
            break
    else:
        return
    year = " (%s)" % following["date"][:4] if following.get("date") else ""
    answer = xbmcgui.Dialog().yesnocustom(
        "Next in %s" % data["name"],
        "Up next: [B]%s[/B]%s[CR][CR]Play it now? Choose Later and it waits for you in Continue Your Sets." % (following["title"], year),
        customlabel="Later", nolabel="No thanks", yeslabel="Play now", autoclose=45000)
    if answer != 1:
        return
    try:
        player.stop()
    except RuntimeError:
        pass
    for _ in range(20):  # let Fen Light finish with the movie that was playing (it marks it watched here)
        if monitor.waitForAbort(0.5) or not player.isPlaying():
            break
    if monitor.waitForAbort(2):
        return
    xbmc.executebuiltin("RunPlugin(%s)" % play_path(following["id"]))


# -- adding the rows to an existing Movies hub ---------------------------------------
ROWS = (
    ("Continue Your Sets", "plugin://script.forge.helper/?mode=continue_sets", "In Progress"),
    ("Movie Sets", "plugin://script.forge.helper/?mode=sets&amp;source=popular", None),
    ("Your Movie Sets", "plugin://script.forge.helper/?mode=sets&amp;source=mine", None),
)


def rows_state():
    """(in place?, note) for the setup checklist."""
    if not os.path.isfile(_rows_file()):
        return True, "Movies hub uses the skin's own list, which has them"
    with open(_rows_file(), "r", encoding="utf-8") as handle:
        text = handle.read()
    missing = [label for label, widget, _ in ROWS if widget.split("?")[1] not in text]
    return (not missing), ("in place" if not missing else "missing: %s" % ", ".join(missing))


def _rows_file():
    return xbmcvfs.translatePath("special://profile/addon_data/script.skinshortcuts/skin.forge-movies-1.DATA.xml")


def add_rows():
    """Add the three set rows to a Movies hub that was customised before they existed. A hub that still uses
    the skin's own list gets them from the skin. Returns how many rows were added."""
    path = _rows_file()
    if not os.path.isfile(path):
        common.log("sets: no customised Movies hub at %s, nothing to add" % path)
        return 0
    with open(path, "r", encoding="utf-8") as handle:
        text = handle.read()
    if "</shortcuts>" not in text:
        return 0
    added = 0
    for label, widget, after in ROWS:
        if widget.split("?")[1] in text:
            continue
        block = ("\t<shortcut>\n\t\t<label>%s</label>\n\t\t<label2 />\n\t\t<icon>DefaultShortcut.png</icon>\n\t\t<thumb />\n"
                 "\t\t<action>ActivateWindow(Videos,%s,return)</action>\n\t\t</shortcut>\n" % (label, widget))
        anchor = text.find("<label>%s</label>" % after) if after else -1
        end = text.find("</shortcut>", anchor) if anchor >= 0 else -1
        if end >= 0:
            end = text.find("\n", end) + 1
            text = text[:end] + block + text[end:]
        else:
            text = text.replace("</shortcuts>", block + "</shortcuts>")
        added += 1
    if added:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(text)
    common.log("sets: %d row(s) added to %s" % (added, path))
    return added
